h07926
s 00064/00000/00000
d D 1.1 99/10/22 16:20:31 cort 2 1
cC
cF1
cK45914
cO-rw-r--r--
e
s 00000/00000/00000
d D 1.0 99/10/22 16:20:31 cort 1 0
c BitKeeper file /sys/repository/quik/second/cmdline.c
cBcort@chimaera.ppc.kernel.org|ChangeSet|19991022221727|10758|2773570c9a2dc5b4
cHchimaera.ppc.kernel.org
cK29571
cPsecond/cmdline.c
cR311945f5fac497f3
cZ-06:00
e
u
U
f e 0
f x 33
t
T
I 2
/* Prompt handling
   
   Copyright (C) 1996 Maurizio Plaza
   		 1996 Jakub Jelinek
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include "quik.h"

#define CMD_LENG	512
char cbuff[CMD_LENG];

void cmdinit()
{
    cbuff[0] = 0;
}

void cmdedit(void (*tabfunc)(void), int c)
{
    int x;

    for (x = 0; x < CMD_LENG - 1 && cbuff[x] != 0; x++)
	;
    prom_print(cbuff);

    if (c == -1)
	c = getchar();
    while (c != -1 && c != '\n' && c != '\r') {
	if (c == '\t' && tabfunc)
	    (*tabfunc)();
	if (c == '\b' || c == 0x7F) {
	    if (x > 0) {
		--x;
		prom_print("\b \b");
	    }
	} else if (c >= ' ' && x < CMD_LENG - 1) {
	    cbuff[x] = c;
	    putchar(c);
	    ++x;
	}
	c = getchar();
    }

    cbuff[x] = 0;
    return;
}

void cmdfill(const char *d)
{
    strncpy(cbuff, d, CMD_LENG);
    cbuff[CMD_LENG - 1] = 0;
}
E 2
I 1
E 1
