h49369
s 00024/00000/00000
d D 1.1 99/10/22 16:20:31 cort 2 1
cC
cF1
cK22293
cO-rw-r--r--
e
s 00000/00000/00000
d D 1.0 99/10/22 16:20:31 cort 1 0
c BitKeeper file /sys/repository/quik/second/ctype.c
cBcort@chimaera.ppc.kernel.org|ChangeSet|19991022221727|10758|2773570c9a2dc5b4
cHchimaera.ppc.kernel.org
cK30088
cPsecond/ctype.c
cR279528fe7574f202
cZ-06:00
e
u
U
f e 0
f x 33
t
T
I 2
#include <string.h>

int tolower(int c)
{
    if ('A' <= c && c <= 'Z')
	c += 'a' - 'A';
    return c;
}

int strcasecmp(const char *s1, const char *s2)
{
    int c1, c2;

    for (;;) {
	c1 = *s1++;
	if ('A' <= c1 && c1 <= 'Z')
	    c1 += 'a' - 'A';
	c2 = *s2++;
	if ('A' <= c2 && c2 <= 'Z')
	    c2 += 'a' - 'A';
	if (c1 != c2 || c1 == 0)
	    return c1 - c2;
    }
}
E 2
I 1
E 1
