h64557
s 00004/00005/00088
d D 1.2 99/10/29 00:14:56 cort 3 2
c Fixes and updates.
cC
cHmedea.ppc.kernel.org
cK13514
e
s 00093/00000/00000
d D 1.1 99/10/22 16:20:31 cort 2 1
cC
cF1
cK17755
cO-rw-r--r--
e
s 00000/00000/00000
d D 1.0 99/10/22 16:20:31 cort 1 0
c BitKeeper file /sys/repository/quik/second/disk.c
cBcort@chimaera.ppc.kernel.org|ChangeSet|19991022221727|10758|2773570c9a2dc5b4
cHchimaera.ppc.kernel.org
cK30350
cPsecond/disk.c
cR165cf12828952f90
cZ-06:00
e
u
U
f e 0
f x 33
t
T
I 2
#include "quik.h"
#include "prom.h"
#include <string.h>

char bootdevice[512];
static char current_devname[512];
static ihandle current_dev;

int open(char *device)
{
    current_dev = call_prom("open", 1, 1, device);
    if (current_dev == (ihandle) 0 || current_dev == (ihandle) -1) {
	printf("\nCouldn't open %s\n", device);
	return -1;
    }
    strcpy(current_devname, device);
    return 0;
}

char * strstr(const char * s1,const char * s2)
{
	int l1, l2;

	l2 = strlen(s2);
	if (!l2)
		return (char *) s1;
	l1 = strlen(s1);
	while (l1 >= l2) {
		l1--;
		if (!memcmp(s1,s2,l2))
			return (char *) s1;
		s1++;
	}
	return NULL;
}

int diskinit()
{
    char *p;
    extern unsigned int is_chrp;

    prom_get_chosen("bootpath", bootdevice, sizeof(bootdevice));
    if (bootdevice[0] == 0) {
	prom_get_options("boot-device", bootdevice, sizeof(bootdevice));
	if (bootdevice[0] == 0)
	    fatal("Couldn't determine boot device");
    }
    p = strchr(bootdevice, ':');
    if (p != 0)
	*p = 0;
D 3
    /* if netbooted */
    if ( strstr( bootdevice, "net" ) )
	    sprintf(bootdevice, "disk:0");
E 3
    /*
     * Hack for the time being.  We need at the raw disk device, not
D 3
     * just a few partitions -- Cort
E 3
I 3
     * just a few partitions. -- Cort
E 3
     */
    if ( is_chrp )
	    sprintf(bootdevice, "disk:0");
    if( open(bootdevice) )
    {
	    /*
D 3
	     * Some chrp machines do not have a 'disk' alias -- Cort
E 3
I 3
	     * Some chrp machines do not have a 'disk' alias so
	     * try this if disk:0 fails
	     *   -- Cort
E 3
	     */
	    sprintf(bootdevice, "/pci@fee00000/scsi@c/sd@8:0");
	    return open(bootdevice);
    }
    return 0;
}

int read(char *buf, int nbytes, long long offset)
{
    int nr;

    if (nbytes == 0)
	return 0;
    nr = (int)call_prom("seek", 3, 1, current_dev, (unsigned int) (offset >> 32),
	      (unsigned int) (offset & 0xFFFFFFFF));
    nr = (int) call_prom("read", 3, 1, current_dev, buf, nbytes);
    return nr;
}

void close()
{
}

int setdisk(char *device)
{
    if (strcmp(device, current_devname) == 0)
	return 0;
    close();
    return open(device);
}
E 2
I 1
E 1
