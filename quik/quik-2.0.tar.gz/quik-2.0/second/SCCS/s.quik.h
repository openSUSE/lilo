h60188
s 00016/00000/00000
d D 1.1 99/10/22 16:20:31 cort 2 1
cC
cF1
cK33052
cO-rw-r--r--
e
s 00000/00000/00000
d D 1.0 99/10/22 16:20:31 cort 1 0
c BitKeeper file /sys/repository/quik/second/quik.h
cBcort@chimaera.ppc.kernel.org|ChangeSet|19991022221727|10758|2773570c9a2dc5b4
cHchimaera.ppc.kernel.org
cK33066
cPsecond/quik.h
cRd02ddbfb72f4da82
cZ-06:00
e
u
U
f e 0
f x 33
t
T
I 2
/*
 * Global procedures and variables for the quik second-stage bootstrap.
 */

extern char cbuff[];
extern char bootdevice[];

int cfg_parse(char *cfg_file, char *buff, int len);
char *cfg_get_strg(char *image, char *item);
int cfg_get_flag(char *image, char *item);
void cfg_print_images(void);
char *cfg_get_default(void);

void *malloc(unsigned);

void prom_pause(void);
E 2
I 1
E 1
