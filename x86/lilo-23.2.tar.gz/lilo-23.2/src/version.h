/* version.h   */

#ifndef VERSION_H
#define VERSION_H

#define VERSION_MAJOR 23
#define VERSION_MINOR 2
#define VERSION_EDIT  ""
#define VERSION_DATE "09-Apr-2011"

#endif
