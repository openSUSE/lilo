extern void fxDisplaySplash(struct boot_fspec_t *filespec);
int fxReadImage(struct boot_file_t *file, unsigned int filesize, void *base);

